// Popup script - no functionality needed
